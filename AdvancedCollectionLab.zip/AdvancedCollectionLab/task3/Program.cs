﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            list.Add(1);
            list.Add(2);
            list.Add(3);
            list.Add(4);
            list.Add(5);
            list.Add(6);
            list.shuffle();

            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
            List<int> copy = DeepCopy(list);
            foreach(var item in copy)
            {
                Console.WriteLine(item);
            }


        }

        
    }
     public static class ListExtensions
    {
        public static void shuffle<T>(this List<T> l)
        {
            for (int i = 0; i < l.Count / 2; i++)
            {
                var temp = l[i];
                l[i] = l[(l.Count - 1) / 2 + i];
                l[(l.Count - 1) / 2 + i] = temp;
            }

        }

       

        // Helper class to perform deep copy by copying properties

        private static List<T> DeepCopy<T>(this List<T> list) where T : new()
        {
            List<T> newList = new List<T>();
            foreach (T item in list)
            {
                if (item == null)
                {
                    newList.Add(item); // Add null as is
                }
                else
                {
                    // Create a new instance of the item's type and copy its properties
                    T newItem = new T();
                    DeepCopyHelper.CopyProperties(item, newItem);
                    newList.Add(newItem);
                }
            }
            return newList;
        }
        
    }
    public static class DeepCopyHelper
    {
        public static void CopyProperties<T>(T source, T destination)
        {
            foreach (var property in typeof(T).GetProperties())
            {
                if (property.CanRead && property.CanWrite)
                {
                    property.SetValue(destination, property.GetValue(source));
                }
            }
        }
    }

}  


