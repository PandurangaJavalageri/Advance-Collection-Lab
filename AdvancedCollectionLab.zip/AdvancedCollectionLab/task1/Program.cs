﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Person> list = new List<Person>();
            Person p1 = new Person { Name = "hi", Age = 30,Id=1 };
            Person p2 = new Person { Name = "hello", Age = 25 ,Id=5};
            Person p3 = new Person { Name = "hanuma", Age = 32 ,Id=7};
            list.Add(p1);
            list.Add(p2);
            list.Add(p3);
           /* List<KeyValuePair<string, int>> keyValueList = new List<KeyValuePair<string, int>>();
            keyValueList.Add(new KeyValuePair<string, int>(p1.Name, p1.Age));
            keyValueList.Add(new KeyValuePair<string, int>(p2.Name, p2.Age));
            keyValueList.Add(new KeyValuePair<string, int>(p3.Name, p3.Age));
            var sortedlist = keyValueList.OrderByDescending(x => x.Value);
            foreach(var k in sortedlist)
            {
                Console.WriteLine($"{k.Key} and {k.Value}");
            }*/
           list.Sort(new Psort());
            foreach (Person p in list)
            {
                Console.WriteLine(p.Age+" "+p.Name);
            }
            Dictionary<int, Person> dict = list.ToDictionary(x=>x.Id,x=>x);
            foreach(var item in  dict)
            {
                Console.WriteLine(item.Key+" "+item.Value);
            }
            var curatedList=dict.Values.Where(value=>value.Age>=30).ToList();
            foreach(var item in curatedList)
            {
                Console.WriteLine(item.Age+" "+item.Name);
            }
           
          
            
            Console.WriteLine();
            Console.WriteLine();
          

        }
    }
    public class Person
    {
        public int Age { get; set; }
        public string Name { get; set; }
        public int Id { get; set; }

    }
    public class  Psort:IComparer<Person>
    {
        public int Compare(Person p1,Person p2)
        {
            return p1.Age.CompareTo(p2.Age);
        }
    }


}
